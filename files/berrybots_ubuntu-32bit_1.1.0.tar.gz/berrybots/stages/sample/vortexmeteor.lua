-- Drone ship loaded and managed by the sample.vortex stage.

function init(ship, world)
  ship:setShipColor(160, 160, 160)
  ship:setLaserColor(255, 255, 255)
  ship:setName("VortexMeteor")
end

function run(enemyShips, sensors)

end
