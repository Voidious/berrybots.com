-- An empty stage with no walls. Load it up and do whatever you want.

function configure(stageBuilder)
  stageBuilder:setSize(1200, 800)
  stageBuilder:setBattleMode(true)
end
