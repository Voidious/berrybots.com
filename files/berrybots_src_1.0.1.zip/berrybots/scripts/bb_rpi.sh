#!/bin/sh
./bbmain $*

