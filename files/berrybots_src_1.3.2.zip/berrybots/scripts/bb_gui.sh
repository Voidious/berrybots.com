#!/bin/sh
./bbgui $*
