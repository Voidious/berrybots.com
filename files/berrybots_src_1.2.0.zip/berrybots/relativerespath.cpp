#include "ResourcePath.hpp"

std::string resourcePath() {
  return std::string("./");
}
