-- A ship that does nothing at all.

function init(ship, world)
  ship:setName("FloatingDuck")
end

function run(enemyShips, sensors)

end
