#!/bin/sh
./bbmain $*
