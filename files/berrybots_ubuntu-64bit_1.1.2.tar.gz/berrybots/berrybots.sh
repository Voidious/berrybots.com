#!/bin/sh
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:./sfml-lib
./bbgui $*
